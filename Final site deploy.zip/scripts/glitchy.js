
const consoleMessages = [
  "Nice pick, perv.",
  "Hope your neighbors aren't watching.",
  "You're definitely going to hell for that one.",
  "Kinky. I like your style.",
  "Better lock the door.",
  "NSFW level: God mode.",
  "Someone's getting weird tonight.",
  "You’re not right—and I respect it.",
  "Oof, that's filthy. Do it again.",
  "Why are you like this? Never change."
];

function reactToDropdownChange() {
  const msg = consoleMessages[Math.floor(Math.random() * consoleMessages.length)];
  document.querySelector('.console-msg').innerText = `"${msg}"`;
}

['age', 'group', 'sex', 'emotion', 'face'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('change', reactToDropdownChange);
});
