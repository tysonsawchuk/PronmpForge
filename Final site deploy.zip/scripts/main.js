
function getSelectedValues() {
  return {
    age: document.getElementById("age").value,
    group: document.getElementById("group").value,
    sex: document.getElementById("sex").value,
    emotion: document.getElementById("emotion").value,
    face: document.getElementById("face").value
  };
}

function generatePrompt() {
  const values = getSelectedValues();
  const raw = `[${values.group}] ${values.emotion} ${values.age}yo ${values.face} girls ${values.sex}`;
  const final = `${values.face} ${values.age}yo girls are ${values.sex} with ${values.emotion} intensity. Whimpering with every touch. Neon rimlight, soft shadows.`;
  document.getElementById("rawOutput").innerText = raw;
  document.getElementById("finalPrompt").innerText = final;
}

function regeneratePrompt() {
  generatePrompt();
}

function copyPrompt() {
  const text = document.getElementById("finalPrompt").innerText;
  navigator.clipboard.writeText(text).then(() => {
    alert("Prompt copied to clipboard.");
  });
}


function generateMoviePrompt() {
  const genre = document.getElementById("genre")?.value || "";
  const setting = document.getElementById("setting")?.value || "";
  const tone = document.getElementById("tone")?.value || "";
  const scene = `A ${tone} ${genre} scene unfolds in a ${setting}. The air is thick with mood. Shot in cinematic widescreen with slow tracking shots.`;

  document.getElementById("movieOutput").innerText = scene;
}
